---
name: Market Coverage Framework
description: Approved Market Coverage & Scan Priority — expanded markets, composite ranking, per-game caps, per-market ROI tracking
---

## What was built

Two new modules wired into the main.py picks pipeline:

### core/game_markets.py
Single Odds API call per sport per session fetches ALL approved markets beyond game totals:
- **MLB**: F5 Total/ML/RL, Team Totals (home+away), Full Game ML, Run Line
- **NBA**: Q1/H1 Total/ML/Spread, Team Totals (home+away), Full Game ML, Spread
- **WNBA**: Team Totals, Full Game ML, Spread

Results cached under `{SPORT}_EXPANDED` key (same slate cache layer as odds_client).

**Two candidate types:**
1. **Scaled total** (F5, team total, Q1, H1): `historical_data` scaled by `_TOTAL_SCALE` factor; flow through `engine.analyze()` unchanged.
2. **Precomputed** (ML, spread): carry `precomputed_edge` / `precomputed_confidence` / `precomputed_model_prob`; bypass NUTS sampler in main.py.

Win probability model: normal approximation of run differential with home-field advantage boost; spread coverage uses same distribution.

### core/market_scanner.py
- `SCAN_PRIORITY` dict: ordered market list per sport (informational + audit)
- `composite_score(edge_pct, confidence, book_count, historical_roi)`: Edge×40% + Conf×30% + Liq×15% + ROI×15% (all normalised to 0–100)
- `apply_per_game_caps(bets, max_per_market=1, max_per_game=3)` → `(kept, demoted)`: enforced after gatekeeper + signal boosts
- `log_market_audit(sport, date, candidates_by_mkt, approved)`: writes JSONL to `data/market_audit/{SPORT}_{DATE}.jsonl`
- `get_market_historical_roi()` → `{market_label: roi_pct}`: feeds composite scoring

## main.py pipeline insertion points
- **Step 1.8** (after player props, before line movement): `fetch_expanded_game_candidates()`
- **Precomputed bypass**: immediately after `bet_id = c["bet_id"]` in simulation loop — checks `c.get("precomputed_edge") is not None`, skips validation + engine.analyze() + V3 calibration, still computes effective_edge and MAS
- **Step 5.2** (after signal boosts): `apply_per_game_caps(approved)`
- **Step 5.3**: `log_market_audit()`

## T009: Per-market performance tracking
- `by_market` column added to `performance_stats` table (TEXT NOT NULL DEFAULT '{}')
- Migration in `init_performance_table()` via try/except ALTER TABLE (safe on existing DBs)
- `rebuild_stats()` queries `json_extract(wager_details, '$.market')` to compute per-market W/L/ROI
- `get_stats()` returns `by_market` dict
- `/api/records` exposes `by_market` in JSON response

## Known behaviour
- WNBA Odds API returns 422 for `team_totals` and some partial-game markets — caught gracefully as `game_markets fetch failed`, pipeline continues.
- Precomputed confidence capped at 82 intentionally — new markets need real-world grading history before earning Diamond tier naturally.
- `by_market` will show `{}` until first bets are graded; feeds composite scoring via `get_market_historical_roi()` once data exists.

**Why:** Engine was scanning only game totals before deciding NO PLAY. Framework ensures every approved market is evaluated for every game before a game is passed over.

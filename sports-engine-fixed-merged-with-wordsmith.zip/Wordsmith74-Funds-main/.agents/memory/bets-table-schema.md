---
name: bets table column names
description: Corrected column names for the bets SQLite table — several names differ from what you'd expect.
---

## Rule
Always use these column names when querying the `bets` table:

| Intended field        | Actual column name      | Notes |
|-----------------------|-------------------------|-------|
| "date" / "pick date"  | `slate_date`            | TEXT YYYY-MM-DD |
| "result"              | `actual_outcome`        | NULL while open; 'win'/'loss'/'push' when graded |
| "confidence score"    | `opening_confidence`    | REAL, nullable; opening snapshot |
|                       | `current_confidence`    | REAL, nullable; updated by revalidation |
| "confidence in JSON"  | `wager_details.confidence_score` | Stored in JSON blob |
| "direction"           | NOT a top-level column  | Lives inside `wager_details` JSON |
| "market"              | NOT a top-level column  | Lives inside `wager_details` JSON |

Direct top-level columns that DO exist: `bet_id`, `sport`, `game_id`, `edge_percentage`, `tier`, `is_locked`, `sent_to_group`, `bookmaker_source`, `line_move_dir`, `slate_date`, `actual_outcome`, `opening_edge`, `current_edge`, `opening_confidence`, `current_confidence`, `revalidation_status`, `timestamp`.

**Why:** Discovered when `conflict_guardian.py` raised `OperationalError: no such column: confidence_score` — the column is in the wager_details JSON blob, not a top-level field.

**How to apply:** Always SELECT `wager_details` and parse JSON in Python to get market, direction, confidence_score, etc. Use `slate_date = ?` (not `date = ?`) and `actual_outcome IS NULL` (not `result IS NULL`) in WHERE clauses.

# DaPickSyndicate

A multi-sport betting picks engine (MLB, NBA, WNBA) that generates AI-calibrated picks, broadcasts them via Telegram, and serves them through a web portal.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/portal run dev` — run the portal (static HTML frontend)
- `python main.py` — run the betting engine (picks generation, scheduling, Telegram broadcast)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 (`artifacts/api-server`)
- Portal: Static HTML/CSS/JS (`artifacts/portal/public/index.html`)
- Engine: Python (`main.py`, `core/`, `output/`)
- DB: SQLite (`data/results.db`) via `node:sqlite` in the API server
- Validation: Zod (`zod/v4`), `drizzle-zod`
- Build: esbuild (CJS bundle)

## Where things live

- `main.py` — production entry point, scheduler + orchestrator
- `core/` — Python engine modules (odds, markets, signals, calibration, props, etc.)
- `core/intelligence/` — CLV, line movement, lineup, pitcher, venue, rivalry intel
- `output/telegram_formatter.py` — Telegram broadcast formatting
- `data/results.db` — SQLite database of picks and results
- `data/slate_cache/` — cached game slates
- `data/market_audit/` — daily market audit JSONL logs
- `config/sports_metrics.json` — sport-specific weights and thresholds
- `artifacts/api-server/src/routes/miniapp.ts` — main API routes serving picks to the portal
- `artifacts/api-server/src/routes/admin.ts` — admin/control routes
- `artifacts/portal/public/index.html` — single-file web portal UI
- `.agents/memory/` — agent memory with engine architecture decisions

## Architecture decisions

- Contract-first API: OpenAPI spec in `lib/api-spec/openapi.yaml`; generated hooks in `lib/api-client-react/`
- SQLite is the runtime DB (not Postgres); `data/results.db` is read by the API server via `node:sqlite`
- Python engine runs as a separate process; API server reads its SQLite output — no direct IPC
- Publication whitelist in `core/market_governance.py` and mirrored in `miniapp.ts` — only approved (sport, market) pairs are broadcast
- All picks go through a decision gatekeeper + revalidation engine before publication

## Product

- Generates calibrated sports picks across MLB, NBA, and WNBA
- Filters picks through market governance, stability, and confidence rules
- Broadcasts via Telegram with formatted cards
- Serves live picks to a web portal at `/`

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Always run `pnpm --filter @workspace/api-spec run codegen` after changing `lib/api-spec/openapi.yaml`
- The API server expects `data/results.db` two levels up from its cwd (`../../data/results.db`)
- Never use `console.log` in server code — use `req.log` in route handlers and the singleton `logger` elsewhere
- `data/results.db` is SQLite (not Postgres); the `lib/db` Drizzle package targets Postgres and is separate

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- Agent memory with engine decisions: `.agents/memory/MEMORY.md`

---
name: Signal governance system
description: Full spec wiring for signal lifecycle, stability filter, conflict guardian, Rule 6, edge void, and scheduler confirmation cycles.
---

## Rule
Every new signal must pass four sequential gates before it is published:

1. **Stability filter** (`core/stability_filter.py`) — rejects a simulation result if `posterior_std` exceeds sport threshold (NBA/WNBA ≤ 2.5 pts, MLB ≤ 0.5 runs). Applied in the sim loop immediately after `engine.analyze()`, before `_derive_bet_params()`.

2. **Rule 6 — Market Uniqueness** (`core/decision_gatekeeper.py`, `check_for_conflicts()`) — within a single run, opposing Over/Under recommendations for the same (game_id, market_norm) are a signal conflict; the lower-edge bet is flagged and demoted.

3. **Signal confirmation gate** (`core/signal_confirmation.py`, `gate_signals()`) — new signals (count=1) are held in `signal_queue` SQLite table until they survive ≥ 3 confirmation cycles AND ≥ min_minutes elapsed (NBA/WNBA: 5 min, MLB: 10 min). `dry_run=True` bypasses this gate entirely.

4. **Conflict guardian** (`core/conflict_guardian.py`, `check_locked_conflict()`) — if a LOCKED pick already exists for the same (game_id, market_norm), the challenger must satisfy ALL 5 replacement conditions: conf gain ≥ 5 pp, edge gain ≥ 25%, edge gain ≥ 40% (projection proxy), signal confirmed upstream, MIS ≥ 40.

Gates 3 and 4 are applied together in `_apply_governance_gates()` in `main.py`, which is called from both `_mode_run` and `_mode_picks` after global tier capping, before DB writes.

## Edge-void collapse
`core/revalidation_engine.py`: `_EDGE_VOID_RATIO = 0.50`. If `current_edge < opening_edge * 0.50`, the bet is voided (original thesis invalidated). This fires before the adverse-line-move void check.

## Scheduler confirmation cycles
`scheduler.py` runs three entries at 02:00, 02:10, 02:20 AM ET:
- 02:00 → `--mode run` (recap + first candidate scan; signals held at count=1)
- 02:10 → `--mode picks` (count=2; MLB still below 10-min floor)
- 02:20 → `--mode picks` (count=3, 20 min elapsed → all sports confirmed → BROADCAST)

## Stability warning log
`core/conflict_guardian.py::log_stability_warning()` appends every conflict event to `data/stability_warnings/{SPORT}_{DATE}.jsonl`.

**Why:** The spec requires traceability for every replacement decision and a clear audit trail if a locked pick is superseded or held.

**How to apply:** Never bypass `_apply_governance_gates()`; use `dry_run=True` only in test/calibrate modes.

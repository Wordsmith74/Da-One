---
name: Slate versioning system
description: Immutable pick-slate versioning — v1 locked at 9 AM, reruns create v2+, change detection, Telegram alerts, MiniApp display.
---

# Slate Versioning System

## DB tables (data/results.db)
- `slate_versions` — one row per broadcast run: date_et, version, triggered_at, trigger_reason, picks_count, is_locked (1=v1 only)
- `slate_version_picks` — full snapshot of every pick in each slate version
- `slate_changes` — diff rows between v1 and each subsequent version (change_type: added/removed/modified)

## Python entry point
`core/slate_versioner.py` — call `snapshot_slate(bets_by_sport, trigger_reason, dry_run)` after every broadcast.

## Where hooked in main.py
- `_mode_run()` → trigger_reason="scheduled" (creates v1, is_locked=1)
- `_mode_picks()` → trigger_reason="manual" (creates v2+, diffs vs v1)

## Change detection thresholds
- odds change ≥ 10 American odds points
- confidence change ≥ 5.0 pp
- edge change ≥ 3.0 pp
- tier, nuke, diamond status — any change flagged

## Telegram alert
`_format_change_alert()` in slate_versioner.py — fires when v2+ has any change vs v1; lists ADDED / REMOVED / CHANGED with old→new fields.

## API endpoints (miniapp.ts)
- GET /api/slate-versions?date= — list all versions for a date
- GET /api/slate-versions/:id — picks for a specific version
- GET /api/slate-changelog?date= — all change rows for a date

## MiniApp UI (index.html)
- Version pills bar (`#sv-bar`) below TODAY'S BROADCAST header — shows "🔒 Opening Slate v1" + "Slate v2 LATEST" pills
- Collapsible 🚨 SLATE CHANGE LOG section (`#changelog-section`) — hidden when no changes, shows per-change cards with color coding (green=added, red=removed, amber=modified)
- `fetchSlateVersions()` called in init() + every 5 min in auto-refresh loop

## Key rules
- v1 is NEVER overwritten — UNIQUE(date_et, version) constraint + is_locked=1
- Reruns are idempotent if picks unchanged (no new version created when nothing differs)
- Existing `bets` table and grading pipeline are untouched — record keeping unaffected by versioning

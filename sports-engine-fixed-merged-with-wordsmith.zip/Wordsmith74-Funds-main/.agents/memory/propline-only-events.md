---
name: PropLine-only WNBA events
description: Fix for WNBA player props being skipped when Odds API 422s but PropLine has data
---

# PropLine-only WNBA Player Props

## The Rule
`get_player_prop_candidates()` in `core/player_props.py` must not skip an event when
`_fetch_event_props` returns `None` (Odds API 422) if `_propline_all` has data.
The guard at line ~1203 is:
```python
if not props_data and not _propline_all:
    continue
```

**Why:** The Odds API does NOT carry WNBA player prop markets (`player_rebounds`,
`player_assists`). It returns HTTP 422 for WNBA events on the event-odds endpoint.
PropLine DOES have WNBA player prop lines. Without this fix, PropLine-only events are
discarded and WNBA props never generate candidates.

**How to apply:** If adding new sports or markets that are PropLine-only, ensure the
same pattern is used — only skip when BOTH Odds API and PropLine have no data.

## What to expect from WNBA props
- PropLine typically provides 2 books for WNBA player props
- Low book count → weak consensus → many gatekeeper rejections
- High σ% in rebounds/assists (>15%) → stability filter rejections
- Picks will publish only when genuine edge exists with adequate consensus
- ESPN bulk scan (56 completed games → 192 players) is the stats source

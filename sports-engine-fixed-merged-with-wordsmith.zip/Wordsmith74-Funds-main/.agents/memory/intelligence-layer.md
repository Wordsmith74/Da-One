---
name: Intelligence layer
description: Four pro-grade modules in core/intelligence/ wired into main.py pipeline as Step 1.5 before Bayesian inference.
---

# Intelligence Layer

## Modules

- `rest_travel.py` — ESPN schedule API → rest days since last game + haversine travel miles → edge adj ±4.0 (back-to-back = -2.5, 3+ days = +0.5, long travel + short rest = additional -1.0)
- `lineup_intel.py` — ESPN injuries API → severity × position impact → edge adj ±6.0 (star out on bet team = heavy negative; star out on opponent = bonus)
- `stat_model.py` — ESPN team stats API → pace-adjusted matchup model → edge adj ±2.0 (team avg vs sportsbook line comparison)
- `clv_tracker.py` — SQLite table `clv_snapshots` in data/results.db; snapshot_odds() at approval time; update_closing_line() at bet close; get_clv_summary() for reporting

## Wiring in main.py

```
Step 1   — _get_game_candidates(sport)
Step 1.5 — _enrich_candidate(c, sport)  ← intelligence layer
             ├─ get_rest_travel_factor()
             ├─ get_lineup_intel()
             └─ get_stat_model_factor()
Step 2   — engine.analyze() [Bayesian + Monte Carlo]
Step 3   — _derive_bet_params() + apply _intel_adj to edge
Step 4   — Build Bet objects
Step 5   — run_gatekeeper() → approved/flagged/discarded
           └─ snapshot_odds() for each approved bet [CLV]
Step 6   — Build BetDisplay + log_dicts
```

## Key design decisions

**Why:** Intelligence modules must be fail-silent — ESPN APIs are external and can be down. Each of the 3 enrichment calls is individually try/except'd in `_enrich_candidate()`. If all three fail, the engine continues with base Bayesian edge unchanged.

**How to apply:** `_INTEL_AVAILABLE` flag gates all intelligence calls at import time; if modules are missing the engine degrades gracefully. Adjustments are summed and capped: `edge = min(50.0, max(-50.0, edge + intel_adj))`.

**CLV beat-rate target:** ≥55% of picks beating closing line = genuine edge confirmed. Tracked via `clv_snapshots` table; `update_closing_line()` must be called at bet close time to complete the CLV record.

**ESPN sport paths:** WNBA=basketball/wnba, NBA=basketball/nba, MLB=baseball/mlb. All public, no auth required. 5s timeout on all calls.

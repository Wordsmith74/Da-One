---
name: WNBA player stats — scoreboard cache
description: ESPN's WNBA athlete APIs return 404; use scoreboard→boxscore chain to build a process-level player stats cache.
---

## The Rule

Never call `_espn_athlete_id()` or `/athletes/{id}/gamelog` for WNBA — both return HTTP 404.
Use `_wnba_stats_from_cache()` instead, which is the WNBA short-circuit at the top of `_espn_player_stats()`.

## What fails (ESPN WNBA API)

| Endpoint | Result |
|---|---|
| `/apis/site/v2/sports/basketball/wnba/athletes?search=` | 404 |
| `/apis/site/v2/sports/basketball/wnba/athletes/{id}/gamelog` | 404 |
| `/apis/site/v2/sports/basketball/wnba/athletes/{id}/stats` | 404 |
| `/apis/site/v2/sports/basketball/wnba/athletes/{id}` | 404 |
| `/apis/common/v3/search?query=...&league=wnba` | 200 but 0 results |

## What works (ESPN WNBA API)

| Endpoint | Result |
|---|---|
| `/apis/site/v2/sports/basketball/wnba/scoreboard?dates=YYYYMMDD` | ✅ — all games that day |
| `/apis/site/v2/sports/basketball/wnba/summary?event={game_id}` | ✅ — full boxscore with REB/AST |
| `/apis/site/v2/sports/basketball/wnba/teams/{team_id}/roster` | ✅ — athlete IDs (but gamelog still 404) |

**Note:** The team roster endpoint gives correct athlete IDs BUT the gamelog endpoint for those IDs still returns 404. Rosters are therefore useless for stat lookup.

**Note:** The schedule endpoint `/teams/{id}/schedule` uses DIFFERENT team IDs than the roster endpoint — same team_id returns a different team's schedule vs. roster. Do not rely on schedule endpoint for team-based filtering.

## The Working Approach

`_build_wnba_stats_cache()` in `core/player_props.py`:

1. Scan scoreboard for the last 21 days (21 API calls)
2. Collect all completed game IDs (~56 games at typical pace)
3. Fetch each game summary boxscore (~56 API calls)
4. Parse `REB` and `AST` columns for every player
5. Store as `{player_display_name_lower: {"REB": [...], "AST": [...]}}` (most-recent-first)

**Result at season peak:** ~192 players cached from ~56 games.

**One-time cost per process:** ~77 API calls × ~0.3s ≈ 23 seconds. Built lazily on first WNBA prop request.

## Markets supported

| Market key | Box column |
|---|---|
| `player_rebounds` | `REB` |
| `player_assists` | `AST` |

`player_points` is suspended (bad win rate) and is in `_SUSPENDED_MARKETS` — do NOT add `PTS` to `_WNBA_BOX_COL` without first restoring it to the whitelist.

## Name matching

`_wnba_stats_from_cache()` does:
1. Exact `displayName.lower()` match
2. Last-name fallback (warns in debug log)

If Odds API sends a slightly different format, check debug logs for `[wnba_cache] last-name match:` lines.

**Why:** ESPN athlete APIs return 404 for WNBA at all endpoints tested. The scoreboard approach is the only reliable ESPN data path, and it builds a comprehensive in-process cache that covers all rostered players.

**How to apply:** Any time WNBA player stats are needed (pre-game or extension), use `_wnba_stats_from_cache()`. If adding new WNBA markets, add the boxscore column to `_WNBA_BOX_COL`.

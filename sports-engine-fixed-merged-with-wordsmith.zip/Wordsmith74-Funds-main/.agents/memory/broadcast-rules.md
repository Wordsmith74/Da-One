---
name: Broadcast rules and sent_to_group flag
description: Exact order and logic for the daily Telegram group broadcast; DB flag for recap filtering.
---

## Broadcast sequence (enforced in `send_daily_picks`)

1. **Nuke pick** — single best unflagged S+ bet (highest edge) across all sports → `format_nuke_pick()`
2. **Diamond pick** — single best unflagged S bet, not already sent → `format_diamond_pick()`
3. **Parlay** — 2-4 Nuke-threshold bets (edge ≥15%, conf ≥88%) **excluding** the Nuke pick already sent → `construct_daily_parlay(exclude_bet_ids=…)`
4. **Edge play** — 1 Diamond-level (S tier) bet per active sport, not already sent → `format_edge_play()`

Silence rule: if a category has no qualifying bets, it is silently skipped (no empty message sent).

## sent_to_group flag

- Column: `bets.sent_to_group INTEGER DEFAULT 0`
- Added by `_migrate_db()` — safe on existing DBs (PRAGMA table_info check before ALTER).
- `log_bet_dict(..., sent_to_group=False)` stores picks as 0 initially.
- `mark_sent_to_group(bet_id)` flips to 1 after each successful Telegram send inside `send_daily_picks`.
- Morning recap (`format_morning_recap` / `calculate_group_roi`) queries `WHERE sent_to_group=1` with UTC date-range boundaries derived from yesterday's ET midnight — handles late-night games (11 PM ET = 3 AM UTC next day) correctly.

**Why:** The recap must only cover bets that were actually pushed to the group, not all bets logged internally. The flag is the authoritative source of truth.

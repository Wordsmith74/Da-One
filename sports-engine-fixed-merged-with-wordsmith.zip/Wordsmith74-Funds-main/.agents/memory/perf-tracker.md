---
name: Cumulative performance tracker
description: How the performance_stats table and rebuild_stats() work; what changed about sent_to_group filtering.
---

## The module
`core/performance_tracker.py` — single source of truth for all cumulative stats.

- `rebuild_stats()` recomputes everything from the `bets` table and upserts the single row in `performance_stats` (id=1). Fully idempotent. Called at the end of `_mode_grade()` in `main.py`.
- `get_stats()` returns the cached row, calling `rebuild_stats()` on first-run bootstrap.
- `get_daily_archive()` returns per-date rows from `daily_archive` (sport='ALL'), newest first.

## Tables added
- `performance_stats` — single row (id=1) with all lifetime metrics as columns + JSON blobs for tier_nuke/tier_diamond/tier_value/by_sport/last_7d/last_30d.
- `daily_archive` — one row per (date_et, sport) pair; rebuilt from scratch on every `rebuild_stats()`.

## sent_to_group filter intentionally REMOVED
Performance tracking (and the graders) originally filtered `sent_to_group=1`. This was wrong — the engine generates more picks than it broadcasts, and all of them should be tracked. The filter was removed from:
- `core/score_grader.py` grade query
- `core/prop_grader.py` grade query
- `core/performance_tracker.py` rebuild_stats() and open count

**Why:** With the filter, June 2's 25 picks showed only 14 in the record (the broadcast subset). Removing it gives the true full-slate performance picture.

## /api/records shape
Returns `{ all (legacy), lifetime, by_sport, by_tier, last_7d, last_30d, by_date }`.
- `lifetime` has all fields: wins/losses/pushes/open/win_rate/roi_pct/net_units/current_streak/current_streak_type/longest_win_streak/longest_loss_streak/last_updated.
- `by_tier` keys: `nuke` (S+), `diamond` (S), `value` (Value).
- `by_date` rows come from `daily_archive` (date_et field, not DATE(timestamp)).
- Portal `renderRecBar(data)` now takes the full response object (not just `data.all`).

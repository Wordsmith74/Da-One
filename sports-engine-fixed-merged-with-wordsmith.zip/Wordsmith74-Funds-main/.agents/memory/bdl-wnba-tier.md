---
name: BallDontLie WNBA tier access
description: Which BDL endpoints work on the free tier vs paid; how the client handles 401 gracefully.
---

## Rule

`BALLDONTLIE_API_KEY` is configured but is on the **free tier**. Free tier only covers:
- `/wnba/v1/players` (player search) ✅
- `/wnba/v1/games` (game schedule) ✅

All other WNBA endpoints return **401 Unauthorized** on the free tier:
- `/wnba/v1/player_stats` ❌ → needs All-Star plan ($9.99/sport/mo)
- `/wnba/v1/player_season_stats` ❌
- `/wnba/v1/odds/player_props` ❌
- `/wnba/v1/standings` ❌
- `/wnba/v1/player_injuries` ❌

**Why:** BDL segments stats behind paid tiers per sport. The WNBA sports package requires at minimum the All-Star plan.

## How the client handles it

`core/bdl_wnba.py` has a `_STATS_TIER: bool | None = None` module flag:
- On first 401 from a stats endpoint → `_STATS_TIER = False`, warning logged
- `is_stats_available()` returns `_STATS_TIER is not False`
- `get_player_stats()` fast-returns `None` immediately if `_STATS_TIER is False`

`_ensure_wnba_cached()` in `player_props.py` checks `bdl_wnba.is_stats_available()` before calling BDL. So:
1. First WNBA player: BDL attempted (2 API calls) → 401 → `_STATS_TIER = False`
2. All subsequent players: BDL skipped in 0ms → ESPN bulk scan fallback

## If BDL plan is upgraded

1. Upgrade to All-Star plan on balldontlie.io for the WNBA sport
2. No code changes needed — `is_stats_available()` will return True on first successful stats call
3. `_STATS_TIER = True` auto-set on first success; BDL becomes the primary source (ESPN scan never runs)

## Correct API endpoint names

From the OpenAPI spec (`/openapi/wnba.yml`):
- Stats: `/wnba/v1/player_stats` (NOT `/wnba/v1/stats`)
- Season averages: `/wnba/v1/player_season_stats`
- Player search: `/wnba/v1/players`
- Games: `/wnba/v1/games`
- Player props: `/wnba/v1/odds/player_props`

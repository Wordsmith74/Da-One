---
name: Signal Calibrator
description: Bayesian signal calibration system — replaces fixed edge scalars with data-driven values that learn from historical bet outcomes.
---

## System

`core/intelligence/signal_calibrator.py` — process-level cache, recalibrates every 4 hours.

**Signal buckets:** steam_confirming, steam_opposing, line_confirming, line_opposing, consensus_high, consensus_medium, sharp_confirmed, reverse_line.

**Research priors (cold-start defaults):**
- steam_confirming: +2.5, steam_opposing: -3.0
- line_confirming: +1.5, line_opposing: -2.0
- consensus_high: +1.5, consensus_medium: +0.8
- sharp_confirmed: +1.2, reverse_line: +1.8

**Bayesian blend formula:**
```
confidence = min(1.0, n_graded / 50)   # 50 = MIN_SAMPLES
blended = prior × (1 - conf) + empirical × conf
```
With 0 data → 100% prior. With 50+ graded bets per bucket → empirical takes over.

**Empirical value:** ROI lift vs baseline, bounded ±8 edge points. Convert: `(bucket_roi - baseline_roi) * 100`.

## Data pipeline (signal tracking)

Signal data now stored on every bet for future calibration:
- `bets.line_move_dir` — calibrator bucket name ("steam_confirming", "line_opposing", etc.). NULL for player props (only game totals get line movement signals).
- `bets.bookmaker_source` — bookmaker name ("Pinnacle", "BetRivers", etc.). Populated via `log_bet_dict(bookmaker_source=...)`.
- `wager_details.consensus_signal` — "high" | "medium" | None for consensus edge.

**Before this change:** `line_move_dir` and `bookmaker_source` were never written to DB (all NULL). 20 graded bets exist but have no signal data — cold-start applies to all buckets.

## line_movement.py change

`_SIGNAL_MATRIX` replaced by `_BUCKET_MAP` (returns bucket name + label). `get_line_movement_signals()` now returns 3-tuples `(edge_adj, description, bucket)` instead of 2-tuples. Callers in `main.py` unpack 3 values: `_lm_adj, _lm_desc, _lm_bucket = _lm`.

## Why

Fixed scalars (+2.5 steam, -2.0 opposing) had no empirical grounding — they were conservative estimates. As bets accumulate with signal data tagged, the system will learn whether these signals actually improve win rate in this specific market context and adjust accordingly.

**How to apply:** Any code adding new signal types must: (1) add to `PRIORS` dict, (2) add bucket detection logic in `_build_cache()`, (3) set `line_move_dir` or `wager_details` field at save time.

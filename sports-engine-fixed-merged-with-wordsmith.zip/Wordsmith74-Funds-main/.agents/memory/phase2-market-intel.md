---
name: Phase 2 market intelligence upgrade
description: Sharp action detection, RLM, steam moves, effective edge, sport-calibrated MIS, PICK UPDATE format — all wired into the full candidate pipeline.
---

## Priority hierarchy (immutable — PRIORITY_ORDER constant)
1. data_reliability → 2. model_projection → 3. effective_edge → 4. simulation_results → 5. sharp_signals → 6. consensus_strength → 7. liquidity_score → 8. market_stability

Market signals ADJUST edge within ±5/7% bounds. They never independently CREATE or REVERSE a pick.

## Sharp book classification (SHARP_BOOKS frozenset)
pinnacle, betcris, circa, bookmaker, draftkings, williamhill_us, betway

## Sport-calibrated liquidity thresholds (SPORT_LIQUIDITY_THRESHOLDS)
- WNBA: full=4 books, moderate=2 books  (thin market — calibrate down)
- NBA/MLB: full=7 books, moderate=3 books

**Why:** WNBA market has fewer books by nature; using 8-book baseline (the old flat threshold) was penalizing WNBA picks unfairly, producing artificially low MIS scores.

## Game total MIS=0 bug (fixed)
Game total candidates (fetch_todays_candidates in odds_client.py) previously never called compute_mis(). MIS was always 0 for all game totals. Fix: compute_mis() + detect_sharp_action() + detect_steam_move() are now called inside the per-direction candidate builder in odds_client.py, before writing to the slate cache.

**How to apply:** If game total MIS is unexpectedly 0, check odds_client.py in the `for direction, lines in (("over", ...), ("under", ...)):` loop — that's where these calls must live.

## Per-book line tracking
Both odds_client.py (game totals) and player_props.py (props) now build `book_lines` lists: `[{"book": str, "line": float}]`. These feed detect_sharp_action(), which separates known sharp books from recreational books to produce a signal_type.

## Effective edge flow
1. Raw edge computed by engine.analyze() + intel adjustments + line movement + consensus signal
2. compute_effective_edge(raw_edge, sharp_signal, rlm_detected, steam_detected, mis_score) applies market signal adjustments
3. Stored as `"effective_edge"` key in wager_details (JSON in bets table)
4. API server (miniapp.ts) exposes it as `effective_edge` in PickRow
5. Portal shows "⚡ Eff Edge" row only when delta from model edge is ≥ 0.05%

## Signal type values
- `sharp_confirm`: sharp books on same side as model (OVER: sharp_line < rec_line by >0.25pt)
- `sharp_contrary`: sharp books opposing model (penalty: -3.5%)
- `no_sharp`: no known sharp book posting the market
- `neutral`: sharp and rec lines aligned within 0.25pt

## RLM proxy
detect_reverse_line_movement(sharp_line, rec_line, direction): returns True when gap ≥ 0.5pt. For OVER: sharp >= rec + 0.5. For UNDER: sharp <= rec - 0.5. No actual bet-% data available (would need premium service).

## Steam move proxy
detect_steam_move(all_lines, book_count, sport): True when spread ≤ 0.5pt AND book_count ≥ SPORT_LIQUIDITY_THRESHOLDS[sport]["full"].

## PICK UPDATE format (telegram_formatter.py)
_fmt_reval_alert() upgraded to show:
- Box-styled "Original Pick" block with conf/edge/odds
- "→ New: ❌ NO PLAY / 📉 DOWNGRADED / 📈 UPGRADED"
- Line movement note if line changed
- Market signal annotations (⚡ Sharp Confirm / 📉 Sharp Contrary / ↩️ RLM / 🔄 Steam)
- Reason (wrapped at 54 chars)

---
name: Player prop line accuracy system
description: Cross-bookmaker consensus validation (Rule 2) + pre-publish re-verification (Rules 4/7/8) + verified_at display on pick cards.
---

## Rule 2 — Cross-bookmaker consensus validation (player_props.py)

`prop_map` now tracks `all_lines: list[float]` per (player, market, direction) across every bookmaker. After collecting all bookmakers:
- `consensus_line = statistics.median(all_lines)`
- If `abs(best_line - consensus_line) > 0.5` (`_LINE_CONSENSUS_MAX_DRIFT`): pick is rejected with WARNING log, `continue` (never enters candidates list).

## Rule 4/7/8 — Pre-publish re-verification (core/line_validator.py)

`pre_publish_verify(bets_by_sport, dry_run)` is called before both `send_daily_picks()` calls in `_mode_run()` and `_mode_picks()`.
- For each approved prop pick: calls `refresh_prop_line(api_sport, event_id, player, market_key, direction)` which re-fetches from Odds API and returns the median line across all books.
- If `|fresh_line - opening_line| > 0.5` (`_LINE_DRIFT_THRESHOLD`): pick is removed from slate, logged WARNING. 
- Game totals (no `bet.player`) pass through without re-verification.
- Missing metadata or API failure: pass through with WARNING (non-fatal).
- `dry_run=True` skips all live API calls.

**Why:** Lines can move significantly between analysis (~6 AM ET) and broadcast (~7 AM ET). A pick on a stale line is a bad pick.

## Metadata registry

`_PROP_META: dict[str, dict]` in `player_props.py` stores per-bet-id metadata:
```
{
  event_id, api_sport, player, market_key, direction,
  opening_line, consensus_line, verified_at ("9:02 AM ET")
}
```
Populated during `get_player_prop_candidates()`, consumed by `core/line_validator.py` via `get_prop_meta(bet_id)`.

## Data flow through the stack

1. `player_props.py` → candidate dict: `verified_at`, `opening_line`, `consensus_line`
2. `main.py` `_run_sport_pipeline()`:
   - `BetDisplay` constructor: `verified_at`, `opening_line`, `consensus_line`
   - `wager_details` JSON: `verified_at`, `opening_line`, `consensus_line`, `bookmaker_source`
3. DB: stored in `bets.wager_details` JSON blob (no schema migration needed)
4. API server: `miniapp.ts` picks route parses and re-exposes `verified_at`, `opening_line`, `consensus_line`
5. Telegram: `_format_single_bet` shows `✓ Verified: HH:MM ET` + `📊 Line Moved: X → Y (+Z)` (if drift ≥ 0.1)
6. MiniApp portal: Analysis expand section shows `✓ Verified` + `📊 Line Moved` rows

## Thresholds

- `_LINE_CONSENSUS_MAX_DRIFT = 0.5` — cross-book consensus gate (player_props.py)
- `_LINE_DRIFT_THRESHOLD = 0.5` — pre-publish re-verification gate (line_validator.py)
- Line movement display threshold: ≥ 0.1 (Telegram), ≥ 0.1 (MiniApp); amber color if ≥ 0.5

"""
Production scheduler daemon — runs main.py modes on a fixed daily schedule.
Launched by start_production.sh alongside the Node.js API server inside the VM.

Schedule (all times America/New_York):
  06:00              --mode reconcile   catch-all scan (7-day lookback, catches anything
                                        missed overnight or during prior downtime)
  08:30              --mode run         full pipeline: recap + picks (signal cycle 1)
  09:15              --mode picks       signal confirmation cycle 2
  10:00              --mode picks       signal confirmation cycle 3 → confirmed picks broadcast
  18:00–02:00 ET     --mode grade       every 15 min — auto-grade settled bets & props
  Sunday 02:10       --mode refine      weekly weight calibration

Grade window covers 6 PM through 2 AM ET to handle late West Coast MLB and
NBA Finals overtime games.  The 6 AM reconcile is the safety net for anything
that finishes after 2 AM or during any gap in scheduler uptime.
"""

import subprocess
import sys
import time
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

ET   = ZoneInfo("America/New_York")
MAIN = "main.py"


def _now() -> datetime:
    return datetime.now(ET)


def _log(msg: str) -> None:
    ts = _now().strftime("%Y-%m-%d %H:%M:%S ET")
    print(f"[scheduler] {ts} — {msg}", flush=True)


def _run(*extra_args: str) -> int:
    cmd = [sys.executable, MAIN, *extra_args]
    _log(f"launching: {' '.join(extra_args)}")
    try:
        result = subprocess.run(cmd, capture_output=False)
        _log(f"finished: {' '.join(extra_args)}  exit={result.returncode}")
        return result.returncode
    except Exception as exc:
        _log(f"ERROR running {' '.join(extra_args)}: {exc}")
        return -1


def _in_grade_window(h: int) -> bool:
    """True during 18:00–23:59 ET or 00:00–01:59 ET (covers West Coast late games)."""
    return h >= 18 or h < 2


def main() -> None:
    _log("daemon started")

    last_reconcile_date:  date | None = None
    last_run_date:        date | None = None
    last_cycle2_date:     date | None = None
    last_cycle3_date:     date | None = None
    last_grade_slot:      tuple[date, int] | None = None
    last_refine_week:     tuple[int, int] | None = None

    while True:
        try:
            now   = _now()
            today = now.date()
            h, m  = now.hour, now.minute

            # ── 06:00 ET: reconcile pass (catch-all 7-day lookback) ──────────
            # Runs before the morning pipeline so any overnight misses are
            # resolved before the day's picks are evaluated.
            if (h, m) >= (6, 0) and (h, m) < (8, 30) and last_reconcile_date != today:
                _log("starting reconcile pass (06:00 slot)")
                _run("--mode", "reconcile")
                last_reconcile_date = today

            # ── 08:30 ET: full pipeline (recap → 60 s → picks) ──────────────
            elif (h, m) >= (8, 30) and last_run_date != today:
                _log("starting full pipeline (08:30 slot)")
                _run("--mode", "run")
                last_run_date = today

            # ── 09:15 ET: signal confirmation cycle 2 ───────────────────────
            elif (
                (h, m) >= (9, 15)
                and last_cycle2_date != today
                and last_run_date == today
            ):
                _log("starting picks cycle 2 (09:15 slot)")
                _run("--mode", "picks")
                last_cycle2_date = today

            # ── 10:00 ET: signal confirmation cycle 3 → confirmed picks ──────
            elif (
                (h, m) >= (10, 0)
                and last_cycle3_date != today
                and last_cycle2_date == today
            ):
                _log("starting picks cycle 3 (10:00 slot)")
                _run("--mode", "picks")
                last_cycle3_date = today

            # ── 18:00–02:00 ET every 15 min: auto-grade ─────────────────────
            # Grade window spans midnight: h >= 18 (evening) or h < 2 (night).
            # Slot key uses today + 15-min bucket; date rolls at midnight so
            # 00:xx and 01:xx slots get the new date automatically.
            elif _in_grade_window(h):
                slot = (today, h * 4 + m // 15)
                if last_grade_slot != slot:
                    _log(f"starting grade (slot {h:02d}:{(m // 15)*15:02d})")
                    _run("--mode", "grade")
                    last_grade_slot = slot

            # ── Sunday 02:10 ET: weekly weight refine ───────────────────────
            elif now.weekday() == 6 and h == 2 and (m, h) >= (10, 2):
                iso      = now.isocalendar()
                week_key = (iso.year, iso.week)
                if last_refine_week != week_key:
                    _log("starting weekly refine (Sunday 02:10 slot)")
                    _run("--mode", "refine")
                    last_refine_week = week_key

        except Exception as exc:
            # Outer guard: unexpected scheduler loop error should never kill
            # the daemon.  Log and continue — next iteration will retry.
            _log(f"LOOP ERROR (continuing): {exc}")

        time.sleep(60)


if __name__ == "__main__":
    main()

---
name: Pitcher Workload Model
description: core/pitcher_workload.py — five-component MLB starter workload forecast feeding K props, F5 totals, and game candidates.
---

## The module

`core/pitcher_workload.py` — standalone module, never generates betting picks.

Public API:
- `get_pitcher_workload(name, team_abbr="", opp_abbr="", *, event_id, pitcher_id)` → `WorkloadProjection`
- `get_game_workload_pair(home_abbr, away_abbr)` → `(home_wl, away_wl)`
- `get_k_workload_scale(wl)` → float, confidence-weighted scale for strikeout proj
- `get_f5_workload_adjustment(home_wl, away_wl)` → float (runs delta for F5 eff_mean)

## Five components (weights)

| # | Name | Weight | Type | Source |
|---|------|--------|------|--------|
| 1 | Sportsbook Signal | 40% | absolute IP | The Odds API `batter_pitcher_outs` (internal only) |
| 2 | Pitch Count Trend | 25% | absolute IP | MLB Stats API game log `numberOfPitches` (L3/L5/season) |
| 3 | Opponent Difficulty | 15% | IP delta ±0.5 | MLB Stats API team hitting (OPS, K%) |
| 4 | Bullpen Fatigue | 10% | IP delta ±0.3 | MLB Stats API team pitching game log, last 3 days |
| 5 | Manager Hook | 10% | absolute IP | Pitcher's own avg IP last 15 starts |

Components 1, 2, 5 are blended as absolute IP estimates using their relative weights.
Components 3, 4 are additive deltas applied after the blend.

## Process-level caches

Four caches prevent duplicate API calls within a run:
- `_WORKLOAD_CACHE` — keyed `"{name}_{date}"` → `WorkloadProjection`
- `_GAME_LOG_CACHE` — keyed `(player_id, season)` → game log splits
- `_TEAM_STATS_CACHE` — keyed `(opp_abbr, season)` → hitting stat dict
- `_BP_USAGE_CACHE` — keyed `(team_abbr, date_str)` → BP IP float
- `_SB_OUTS_CACHE` — keyed `"event_{last10_of_name}"` → implied IP

The schedule cache from `pitcher_intel._SCHEDULE_CACHE` is shared via import.

## Integration points

1. **player_props.py** — after `_weighted_projection()` for `pitcher_strikeouts` (MLB only):
   - calls `get_pitcher_workload(player_name, event_id=event_id)`
   - applies `get_k_workload_scale(wl)` as a multiplier on `weighted_proj`

2. **game_markets.py** `_process_scaled_total()` — after `eff_mean` is computed:
   - for `totals_first_5_innings` + sport == "MLB" only
   - calls `get_f5_workload_adjustment(home_wl, away_wl)` and adds delta to `eff_mean`
   - uses `print()` for logging (not `logger`; game_markets.py style)

3. **main.py** `_enrich_candidate()` — after `pitcher_intel` block, within `if sport.upper() == "MLB":`:
   - calls `get_game_workload_pair(home_abbr, away_abbr)`
   - stores results as `c["workload_home"]` / `c["workload_away"]` on the candidate dict
   - logs `WORKLOAD DISCREPANCY` at INFO level when `discrepancy_flag=True`

## Discrepancy detection

If `|model_ip − sb_implied_ip| ≥ 1.0 innings` → `discrepancy_flag=True`.
Logged at INFO level; does not block or alter simulation (signal only for now).

## Key constants

- `LEAGUE_AVG_IP = 5.5`    (used as default baseline when no components have data)
- `LEAGUE_AVG_K9 = 9.2`
- `LEAGUE_AVG_RA9 = 4.50`
- `_LEAGUE_F5_RA = 4.68`   (empirical first-5 total runs, both teams combined)
- `_DISCREPANCY_THRESH = 1.0` innings

## Why

Outs Recorded was removed as a betting market (too unreliable, polluted W/L stats).
Workload keeps the IP/K/RA signal alive as **internal forecasting only** —
feeding the strikeout projection (which actually generates picks) and the F5 prior.

**How to apply:**
- Adding a new MLB market that depends on starter depth → import `get_pitcher_workload()`
- Never call `get_pitcher_workload()` to produce a bet on "outs" or "innings pitched" directly
- When opp_abbr and team_abbr are unknown at call time, pass empty strings and rely on name-based schedule matching

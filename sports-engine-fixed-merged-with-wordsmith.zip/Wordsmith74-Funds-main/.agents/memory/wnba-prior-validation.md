---
name: WNBA prior mismatch and validation gates
description: Root cause of confidence=99.0 on losing WNBA bets; three fixes applied in odds_client.py and main.py.
---

## The bug

`_GAME_TOTAL_PRIOR` in `core/odds_client.py` was a flat `{sport: {mean, std}}` dict.
WNBA `mean=165.0` is the correct full-game total (both teams combined).
But the Odds API's `markets=totals` endpoint can return bookmaker lines that are team-specific (~84.5 for one team) filed under the same `totals` key.
When a 84.5 line landed in the candidate pool, `_synthetic_history()` still generated 50 values centred at 165.0.
The Bayesian engine then computed `z = |165 - 84.5| / posterior_std ≈ huge` → `confidence = 99.0`, direction = Over.
SEA scored 56. The model was comparing a game-total prior to a team-total line — two different quantities.

## Fix 1: Market-aware prior (`core/odds_client.py`)

`_GAME_TOTAL_PRIOR` restructured to `{sport: {market_type: {mean, std}}}`:
```python
"WNBA": {
    "totals":     {"mean": 165.0, "std": 8.0},   # full game
    "team_total": {"mean": 80.0,  "std": 6.0},   # one team
}
```
Prior lookup now uses `.get("totals", ...)` since the current fetch always requests `markets=totals`.
If a team_totals market is added later, it automatically picks up `team_total` prior.

## Fix 2: Sportsbook line sanity bounds (`main.py` — `_LINE_BOUNDS`)

```python
"WNBA": {"totals": (135.0, 200.0), "team_total": (55.0, 100.0)}
```
Any line outside the bounds for its sport+market → rejected before NUTS runs.
PHX 166.5 labeled team_total: blocked (166.5 > 100 upper bound).
SEA 84.5 labeled totals: blocked (84.5 < 135 lower bound).

## Fix 3: Historical data range gate (`main.py` — `_HIST_BOUNDS`)

```python
"WNBA": {"totals": (130.0, 200.0), "team_total": (40.0, 115.0)}
```
If majority (>50%) of hist values fall outside range → reject.
Rolling-3 vs full-mean divergence >30% → log warning (non-fatal).

## Fix 4: Thin-data tier ceiling (`main.py` — Step 3.7 + Step 5.5)

When `closed non-prop bets for sport < _MIN_THIN_DATA_BETS (15)`:
- All non-prop candidates for that sport get `bet_id` added to `_thin_data_ids`.
- After gatekeeper: any thin_data bet with tier S+ or S is clamped to Value.
- `wager_details["thin_data"] = True` written to DB for audit.
- `supporting_factor` gets "⚠️ Early calibration — fewer than 15 graded picks" appended.
- Player props are fully exempt.

**Why:** Confidence score formula (`50 + z*25`) is a mathematical certainty measure, not a track-record measure. Damping confidence mid-pipeline pollutes the formula. The tier ceiling applies after gatekeeper without touching the underlying scores.

## What each fix caught on yesterday's picks

| Pick | Blocked by |
|------|-----------|
| SEA Over 84.5 | Fix 2 — line 84.5 < WNBA/totals lower bound 135 |
| PHX Under 166.5 | Fix 2 — line 166.5 > WNBA/team_total upper bound 100 |
| PHX Under 78.5 | Passes gates; Fix 4 caps to Value tier |
| Ogunbowale Over 22.5 | Passes gates (prop); Fix 4 caps to Value tier |
| Copper 3PT Over 1.5 | All fixes pass — WIN preserved as Diamond |

## Key rule

Never damp confidence_score directly to inject track-record uncertainty — it has a precise mathematical meaning tied to tier thresholds. Use a separate flag (thin_data) and apply the ceiling after tier assignment.

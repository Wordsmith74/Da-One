---
name: V3.0 calibration system
description: Four new modules that fix inflated confidence/edge on game totals; wired into gatekeeper Steps 1c/1d and main.py pipeline.
---

## Modules

| File | Purpose |
|---|---|
| `core/edge_calibrator.py` | Compress raw simulation edge to realistic range |
| `core/confidence_caps.py` | Hard ceilings per sport × market × tier |
| `core/market_agreement.py` | 0–100 score from sharp/RLM/steam/MIS/line-move signals |
| `core/integrity_filters.py` | Missing-element checks downgrade or discard Nuke/Diamond picks |

## Edge calibration formulas

- **Game markets** (totals, spreads): `1 + (raw − 10) / 40 × 9` → [10%, 50%] raw → [1%, 10%] calibrated
- **Player props**: `2 + (raw − 8) / 42 × 13` → [8%, 50%] raw → [2%, 15%] calibrated
- Applied in `main.py` pipeline **BEFORE** intel adjustments (so rest/travel/lineup ±values remain meaningful on the new scale)
- Applied **AFTER** `_derive_bet_params()` which still uses the old 50% cap internally

## Confidence caps (post-gatekeeper Step 1b, Step 1c)

| Market | Nuke | Diamond | Edge |
|---|---|---|---|
| MLB Totals | 85 | 80 | 75 |
| NBA Totals | 88 | 83 | 78 |
| WNBA Totals | 86 | 81 | 76 |
| All Props | 92 | 87 | 82 |

Confidence thresholds for tier *qualification* are unchanged: 85 / 78 / 68.

## New tier edge thresholds (calibrated scale)

| Sport | Nuke | Diamond | Edge |
|---|---|---|---|
| MLB | 3.5% | 2.0% | 1.0% |
| NBA | 4.0% | 2.5% | 1.5% |
| WNBA | 3.5% | 2.0% | 1.0% |

Near-miss window tightened to 0.5% (was 2.5% on the old inflated scale).

## Market agreement score

Baseline 50, then:
- `sharp_confirm` +25, `sharp_contrary` −25
- `rlm_detected` +15
- `steam_detected` +10
- `mis_score ≥ 70` +10
- `line_move_dir confirming` +10, `opposing` −10

Tier floors: Nuke needs ≥ 75, Diamond ≥ 50, Edge ≥ 25. Below floor → downgrade one tier.
Confidence penalty: `max(0, (75 − score) × 0.3)` when score < 75.
Edge penalty: `max(0, (50 − score) × 0.05)` when score < 50.

## Integrity filters (Nuke/Diamond game markets only)

MLB required elements: starting_pitcher, bullpen_score, park_factor, weather, market_agreement_score
NBA required elements: lineup_quality, injury_report, pace_factor, market_agreement_score
WNBA required elements: lineup_quality, injury_report, market_agreement_score

Missing 1 → downgrade one tier. Missing 2+ → discard.

## raw_result wiring

`raw_result = c` (the full candidate dict) is now passed when building Bet objects in Step 4 of `main.py`. This means gatekeeper Steps 1d (market_agreement / integrity_filter) can read all candidate enrichment fields via `bet.raw_result`. Previously `raw_result` defaulted to `{}`, making Steps 6/7 dormant.

## Revalidation Telegram alerts (core/revalidation_engine.py)

`_send_regrade_telegram_alert(change)` added. Fires for every non-confirm revalidation (voided / downgraded / upgraded). Uses `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` env vars. Result (0/1) stored in `pick_regrade_history.alert_sent`.

## pick_regrade_history DB table

New table in `core/results_tracker.py` `init_db()`. One row per non-confirm revalidation event. Key columns: `bet_id`, `prev_tier`, `new_tier`, `prev_edge`, `new_edge`, `change_type`, `alert_sent`, `snapshot_json`.

## MiniApp (portal/index.html)

- `classifyEdge(e)` — returns label+color for calibrated edge (Exceptional/Rare/Elite/Strong/Small/Marginal)
- `fmtAgreement(score)` — returns label+color for market agreement
- `.edge-row` flex container holds edge-pill + `.edge-class-chip`
- `.pick-status-banner` shows VOIDED / DOWNGRADED / UPGRADED prominently above the reval-badge
- Market agreement score displayed in expand rows when available in pick data

---
name: Prediction engine architecture
description: Five-layer Python engine structure; which file is the real entry point vs helper.
---

## Layers

| Layer | File | Role |
|-------|------|------|
| Prediction | `core/decision_orchestrator.py` | Weighted projections from `config/sports_metrics.json` |
| Simulation | `core/simulation_engine.py` | Bayesian (PyMC) + Monte Carlo |
| Gating | `core/decision_gatekeeper.py` | Tier assignment, conflict detection |
| Output | `output/telegram_formatter.py` | Message formatting + Telegram API |
| Tracking | `core/results_tracker.py` | SQLite DB, ROI, learning loop |

## Entry points

- `main.py` — **production entry point**; argparse, logging, lock file, error alerting, cron-safe.
- `run.py` — **slate builder**; defines `build_slate(sport)` which wires the first three layers together using mock data (real API data TBD). `main.py` imports it.

## Key data flow

`main.py --mode run` → `_build_and_log_picks(sports)` → `build_slate(sport)` → Orchestrator + SimEngine + Gatekeeper → `send_daily_picks(bets_by_sport)` → Telegram

**Why:** `run.py` was the original entry point; `main.py` wraps it with production concerns without duplicating simulation logic.

---
name: Picks engine run time + testing pattern
description: How to manually trigger and verify a picks run; known blockers for same-day re-runs.
---

## Rule
Never run `python3 main.py --mode picks` synchronously in the bash tool — it takes ~250 seconds and will always hit the 120s tool timeout.

**Why:** 53 MLB candidates × 2 NUTS chains × 3000 iterations ≈ 106s of sampling alone; total wall time ~250s.

**How to apply:**
Use `nohup python3 main.py --mode picks > /tmp/picks_out.log 2>&1 &` and check results after the process finishes.

## Game Truth Protocol blocks same-day re-runs

After a successful picks run, `data/game_truth_state.json` stores the `locked_line` for every game evaluated. On re-run with cached odds, `current == locked_line` → delta = 0.00 → all candidates suppressed.

**Fix:** Clear the state file before re-running: `echo '{}' > data/game_truth_state.json`

The slate cache (`data/slate_cache/`) is safe to keep — it only affects whether fresh Odds API credits are consumed.

## Signal queue force-confirm (for testing / recovery)

When picks are at cy=1 and you need to publish immediately (skipping the 3-cycle wait):

```python
import sqlite3
from datetime import datetime, timedelta
db = sqlite3.connect('data/results.db')
backdated = (datetime.now() - timedelta(minutes=15)).isoformat()
db.execute(
    "UPDATE signal_queue SET cycle_count=3, status='confirmed', first_seen_at=? "
    "WHERE status='candidate' AND created_date=date('now','localtime')",
    (backdated,)
)
db.commit()
```

This satisfies both the `cycle_count >= 3` AND `elapsed_min >= min_minutes` criteria.

## `--dry-run` flag behavior

`--dry-run` IS a registered argparse argument (line ~2458 main.py). It bypasses Telegram and sleep calls. However, `log_bet_dict()` at line ~1929 is called unconditionally — picks ARE written to DB even with `--dry-run`. The flag appears to hang for unknown reasons; prefer the background nohup approach instead.

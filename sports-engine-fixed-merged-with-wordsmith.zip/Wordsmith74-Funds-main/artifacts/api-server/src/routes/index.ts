import { Router, type IRouter } from "express";
import healthRouter  from "./health";
import miniappRouter from "./miniapp";
import adminRouter   from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(miniappRouter);
router.use(adminRouter);

export default router;

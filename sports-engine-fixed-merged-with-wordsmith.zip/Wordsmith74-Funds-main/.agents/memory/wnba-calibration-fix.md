---
name: WNBA calibration root-cause fix
description: Three layered bugs caused 0 WNBA approved picks; the fix yielded 2 approved (1 Nuke + 1 Value) and revealed a conflict-detection design flaw for bidirectional candidate generation.
---

## The three bugs (all must be fixed together)

### Bug 1 — Only OVER candidates generated (root cause of 0 picks)
Previous code generated only `direction='over'` candidates.
For WNBA where `league_mean=165 < sportsbook_line=166.5`:
  - P(OVER) ≈ 20% → edge = –32% → discarded
  - P(UNDER) ≈ 80% → edge = +28% → S+ (Nuke) — but never generated.

**Fix:** Generate both OVER and UNDER per game in `fetch_todays_candidates()`.
Both share the same `shared_history`; the engine evaluates each direction independently.

### Bug 2 — Synthetic history sample mean ≠ league_mean (data integrity)
With `random.seed(int(league_mean * 1000))` and `n=10`, WNBA history produced sample
mean = 166.47 (not 165.0). Since the posterior mean is pulled toward the data mean,
it ended up sitting at 166.47 — right at the sportsbook line — giving z≈0, edge≈0.

**Fix (a):** Force exact centering: subtract empirical sample mean, then shift to league_mean.
```python
sample_mean = sum(raw) / n
return [round(mean + (r - sample_mean), 1) for r in raw]
```
**Fix (b):** Use a game-specific seed (hash of game_id) so different games get distinct profiles.
**Fix (c):** Increase n from 10 → 50. With n=50: posterior_std ≈ data_std/√50 = 5.6/7.07 ≈ 0.79 for WNBA, giving z≈1.90 for a 1.5-point edge → conf≈97.5 (Nuke-tier).

### Bug 3 — Conflict detection blocked all picks (design flaw)
`check_for_conflicts()` flagged OVER and UNDER for the same game as "Volume conflict" because
they were same team, same market, opposite directions — even when OVER had negative edge
and would be discarded anyway.

Result: UNDER (tier=S+) was flagged because its worthless mirror OVER existed.
0 approved bets for every sport.

**Fix:** Only raise a conflict when BOTH bets independently have a tier assigned:
```python
if a.tier is None or b.tier is None:
    continue   # no real conflict — worthless side can't block the good side
```

**Why:** Generating both directions is intentional. The conflict rule was designed for
human-curated batches where duplicating a market signals a mistake. With bidirectional
generation, one side will always have negative edge; blocking the good side on this basis
is incorrect.

## Seasonal prior decay
`_seasonal_std_multiplier(sport)` controls the synthetic history spread:
- Pre-season (Oct/Nov): mult = 1.40 (high uncertainty, wide priors)
- Mid-season (June):    mult = 0.70 (50% reduction — more data exists)
- Late season (Aug/Sep): mult = 0.50

Implemented as a monthly schedule; default = 0.70.

## Engine behavior with PyMC NUTS
The engine model is:
  `mu ~ Normal(league_mean, league_std)`
  `sigma ~ HalfNormal(league_std)`
  `obs ~ Normal(mu, sigma)`
  `posterior_std = np.std(posterior_mu)`  ← std of the posterior distribution of mu

Confidence formula: `conf = 50 + (|posterior_mean - line| / posterior_std) * 25`

With n=50 centered data:
  posterior_std ≈ data_std / √n
  For WNBA (data_std = 8.0 × 0.70 = 5.6, n=50): posterior_std ≈ 0.79
  For a 1.5-point edge (league_mean=165, line=166.5): conf ≈ 97.5 → Nuke ✓

## Validation results (June 01, 2026)
- WNBA: 2 approved (PHX UNDER 166.5 → Nuke edge=+48% conf=98; DAL UNDER 166.0 → Value)
- MLB: 4 Nuke (STL/SEA/MIL OVER 7.5, CIN UNDER 9.5) + 2 Value
- Combined: 6 approved, exceeds 4–6 target ✓

## New capabilities added
- `--mode calibrate-odds`: A/B calibration with ranked breakdown per candidate
- Feature Variance Report: fired when 0 approved, shows edge/conf/prob/line σ
- Near-miss Step 4 in gatekeeper: edge≥2.5% AND conf≥65 → flagged for secondary analysis

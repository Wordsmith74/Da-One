---
name: Venue Intelligence Module
description: Home/Away/Neutral venue module — data sources, edge calculation, tag thresholds, park factor limits.
---

## Data sources
- **MLB**: MLB Stats API schedule (same `statsapi.mlb.com` endpoint as rivalry_intel) — filter completed games for home/away W-L + avg runs scored/allowed. Process-level `_MLB_SCHEDULE_CACHE` keyed by abbr.
- **NBA/WNBA**: ESPN team record endpoint (`site.api.espn.com/...teams/{abbr}`) returns `record.items` with `type: home | road | total`. Home/road WP available directly. Process-level `_ESPN_RECORD_CACHE` keyed by `(abbr.lower(), sport.upper())`.
- **Park factors**: Hardcoded `_MLB_PARK_FACTORS` dict in `venue_intel.py` (2025 estimates). Keyed by MLB abbr.

## Edge calculation (capped ±5.0)
1. **Park factor** (MLB only, ±3.0 max): `park_factor_adj(home_abbr, direction)` — reverses sign for 'under' direction.
2. **Venue split matchup** (±2.0 max): home WP deviation from league baseline (MLB 54%, NBA 59.5%, WNBA 56%) + road WP category + MLB scoring splits.

## Tag thresholds
- `STRONG HOME EDGE` + `HOME FIELD BOOST`: home_wp deviation ≥ +12pp above league avg
- `HOME FIELD BOOST` only: deviation +7–12pp
- `STRONG ROAD TEAM`: away road_wp ≥ 48%
- `MAJOR VENUE ADVANTAGE`: requires **both** home_wp ≥ 60% AND road_wp ≤ 38%
- `HIGH-SCORING PARK`: park_adj ≥ +1.5
- `PITCHER-FRIENDLY PARK`: park_adj ≤ −1.5
- `PARK FACTOR IMPACT`: any nonzero park label (park factor known for home team)

## Wiring in main.py
- Import: `from core.intelligence.venue_intel import get_venue_factor` (line ~166)
- Called in `_enrich_candidate()` after rivalry block; direction derived from `c.get("market", "")` — 'under' in market name → direction='under'
- Edge included in `_intel_adj` sum: `getattr(_intel.get("venue"), "edge_adjustment", 0.0)`

## Sample outputs (2025 season)
- BOS@NYY (over): park +0.5 + split +1.7 = **+2.2** [HOME FIELD BOOST, STRONG ROAD TEAM, PARK FACTOR IMPACT]
- COL@SD (over): park -2.0 + split -0.7 = **-2.7** [PITCHER-FRIENDLY PARK]
- MIA@BOS NBA (over): split +1.5 = **+1.5** [STRONG HOME EDGE, HOME FIELD BOOST]

**Why:** Minimum 5 games required before home/road WP is used (prevents early-season noise). WNBA at season start (< 5 home games) returns 0 adj.

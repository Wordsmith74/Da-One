---
name: Playoff context wiring
description: How context/recent_n/volatility_index flow from game candidates through engine.analyze(); production candidates default to regular
---

## Rule
Every game candidate dict in `_get_game_candidates()` carries three playoff-context fields. `_run_sport_pipeline()` reads them and passes them to `SimulationEngine.analyze()`.

**Why:** Keeps the pipeline uniform — the engine never has to guess context; it always receives an explicit signal. Future live-data connectors just need to populate these three fields.

**How to apply:** When wiring real API data, set `"context": "playoff"`, `"volatility_index": <sport-specific float>`, and `"recent_n": <N>` in the candidate dict. The rest of the pipeline is unchanged.

## Field contract (per candidate)
```python
"context":          "regular"  # or "playoff"
"volatility_index": None       # None → SimulationEngine.PLAYOFF_VOLATILITY[sport] default
"recent_n":         5          # games sliced from tail of historical_data in playoff mode
```

## Engine behavior (SimulationEngine.analyze)
- `context="regular"` → uses full `historical_data`, league_std unchanged, MC sigma unchanged
- `context="playoff"` → slices `historical_data[-recent_n:]`, divides `league_std /= vol`, divides `posterior_std /= vol` before Monte Carlo
- `vol` = `volatility_index` if supplied, else `PLAYOFF_VOLATILITY[sport]` (WNBA=1.8, NBA=1.8, MLB=1.3)

## Return keys added by playoff path
`sim["context"]`, `sim["volatility_index"]`, `sim["active_data_n"]` — used by `_run_one_calibration()` for the results table.

## Production defaults
All current mock candidates use `"context": "regular"`. Flip to `"playoff"` when live playoff schedules are detected via the API connector.

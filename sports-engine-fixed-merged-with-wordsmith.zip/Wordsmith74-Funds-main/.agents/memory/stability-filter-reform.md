---
name: Stability filter reform — relative σ%
description: V3.0 stability filter rewrite; relative uncertainty as primary metric, absolute as emergency backstop.
---

## Rule
The primary stability metric is **relative spread** = σ / |mean| × 100%. The old absolute σ threshold (MLB=0.50) was rejecting valid pitcher prop picks that had large σ in absolute terms but low uncertainty relative to their projected mean.

**Why:** A pitcher projected for 18 outs (6 innings) with σ=1.0 has 5.6% relative spread — very stable. The old MLB threshold of 0.50 was sport-oblivious and rejected this as "unstable".

**How to apply:** `core/stability_filter.py` — the single source of truth.

## Thresholds (V3.0)

| Tier | Relative σ% | Label |
|------|-------------|-------|
| Elite | < 8% | pass |
| Acceptable | 8–12% | pass |
| Caution | 12–15% | pass (with log warning) |
| Reject | > 15% | STABILITY REJECT |

Absolute guardrails (emergency only — overrides relative pass):
- MLB: σ > 5.0 → REJECT regardless
- NBA/WNBA: σ > 20.0 → REJECT regardless

## Log message format (V3.0)

Pass: `[SPORT] bet_id: STABILITY PASS — relative σ=X.X% (Elite/Acceptable/Caution)  σ=Y  proj=Z`
Reject: `[SPORT] bet_id: STABILITY REJECT — relative σ=X.X% > 15.0% threshold (SPORT  σ=Y  proj=Z)`

The old format `"Model unstable: σ=X > 0.50 (MLB)"` indicates a pre-V3.0 run from cache/pyc.

## Example impact
Rasmussen outs_recorded: σ=1.067, proj≈14.5, relative=7.0% → **PASS** (was REJECT under old 0.50)
Luzardo outs_recorded: σ=0.768, proj≈20.0, relative=3.8% → **PASS** (was REJECT)
Valdez strikeouts: σ=0.529, proj≈6.4, relative=8.2% → **PASS** (was REJECT)

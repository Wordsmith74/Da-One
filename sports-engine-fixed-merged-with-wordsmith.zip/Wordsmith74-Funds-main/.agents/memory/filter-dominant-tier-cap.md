---
name: Filter-dominant tier cap
description: _apply_global_tier_cap() now elects a dominant (sport, market) filter and restricts Nuke/Diamond to that filter's picks only.
---

## Rule
The tier cap groups all gatekeeper-eligible (Nuke+Diamond) picks by `(sport, market_normalized(bd.bet.market))`. The **dominant filter** wins by:
1. Highest count of Nuke+Diamond picks in the group
2. Highest average composite score (edge×0.6 + conf×0.4) — tie-breaker
3. Highest individual composite score — final tie-breaker

Within the dominant filter: rank 1 → Nuke, rank 2 → Diamond (never forced), rank 3+ → Gold Standard. All picks from non-dominant filters → Gold Standard.

**Why:** User spec: "Nuke and Diamond must come from the filter that produced multiple Nuke picks." Ensures the engine's hottest pipeline earns both top slots rather than cherry-picking globally.

**How to apply:** Every time `_apply_global_tier_cap()` runs. DRS/restricted-market gk ceilings are still respected (a DRS-capped Diamond can't be promoted to Nuke even if it's rank 1).

## Key edge cases
- No filter has >1 pick → tie on count=1 → avg composite wins → single pick = Nuke only, no Diamond that day (never forced).
- DRS cap: if gk_tier==Diamond (DRS<75 demoted it from Nuke), the Nuke slot check (`gk_tier==Tier.NUKE`) fails → pick correctly lands at Diamond, not Nuke.
- MiniApp shows "No Nuke Pick qualified today" banner when Nuke slot is empty.

## Re-run pattern (manual slate reset)
1. Delete today's bets: `DELETE FROM bets WHERE slate_date='YYYY-MM-DD'`
2. Clear signal_queue: `DELETE FROM signal_queue WHERE created_date='YYYY-MM-DD'`
3. Clear game truth: write `{}` to `data/game_truth_state.json`
4. Run engine: `python3 main.py --mode picks` (takes ~250s; do NOT run two processes simultaneously)
5. Force-confirm signals for second pass: set `cycle_count=3`, backdate `first_seen_at` by 20 min
6. Re-run engine again to publish confirmed candidates

---
name: EU Bookmaker Stale-Line Filter
description: Matchbook filtered from all game-total line selection; consensus deviation gate added to all total processors.
---

## Rule
Matchbook is blocked at three levels:
1. `odds_client.py` bookmaker loop — skipped before `over_lines`/`under_lines` collection
2. `odds_client.py` `_SHARP` set — Matchbook removed so it is never preferred even if it re-appears via other regions
3. `game_markets.py` top-level `mkt_books` collection — filtered before any per-market processor sees it
4. `game_markets.py` `_process_scaled_total()` — redundant filter for safety
5. `game_markets.py` `_process_team_total()` — redundant filter for safety

## Consensus deviation gate (Option A)
After `_best_side()` selects a line in all total processors:
- Compute consensus = median of all collected lines for that direction
- Drift limit: MLB 0.5, NBA 1.0, WNBA 0.5 (constant defined at call site)
- If `abs(best_line - consensus) > drift_limit`: fall back to best-priced book within tolerance; if none, reject direction entirely
- In `odds_client.py fetch_todays_candidates()`: same thresholds (tightened from 0.75 to 0.5 for MLB/WNBA)

**Why:** Matchbook (EU-only) consistently showed stale lines 0.5–1.0 pts off the US market for MLB totals, creating false edge. Pinnacle (EU/US) can also diverge for WNBA but is kept as valid (passes the consensus gate when within tolerance).

**How to apply:** Any new total-market processor added in future must include the Matchbook skip + consensus gate pattern.

## Known edge cases
- Betsson (EU) and 888sport (EU): may show lines at exactly ±0.5 from consensus — these pass the strict `>` gate. Monitor for drift patterns.
- For UNDER, a line BELOW consensus is harder to hit. The gate prevents extreme cases but 0.5 is allowed by design.

## Drift occurred (original slate)
- CHC OVER 8.5 @ Matchbook → consensus was 8.0 at run time, drifted to 7.5. Drift=0.5 which was below the old threshold of 0.75, so it passed. With new 0.5 limit it would be rejected.
- MIN UNDER 159.5 @ Pinnacle → consensus was 160.0, market moved to 162.5 post-publication.

---
name: Gold Standard tier system
description: Edge tier replaced by Gold Standard; ranked assignment logic; all DB/UI/API mappings.
---

# Gold Standard Tier

## Rule
`Tier.GOLD = "Gold Standard"` replaces `Tier.EDGE = "Edge"` everywhere. No pick may ever be labeled "Edge" again.

## Ranked Assignment (replaces threshold-based global cap)
After all per-pick gatekeeper quality filters run, `_apply_global_tier_cap()` in `main.py` sorts ALL eligible picks by composite score (`edge_pct × 0.6 + confidence × 0.4`) and assigns:
- Rank 1 → Nuke (must have cleared Nuke threshold in gatekeeper)
- Rank 2 → Diamond (must have cleared Diamond threshold)
- All others → Gold Standard

**Why:** Prior Edge tier showed −79% ROI; ranked selection ensures best available signal always gets highest tier, regardless of which sport or market it comes from.

## DB
- `tier_value` column in `performance_stats` repurposed for Gold Standard data (no schema migration needed).
- Migration run: 73 rows normalised (36 Edge/Value→Gold Standard, 35 S+→Nuke, 2 S→Diamond).

## API
- `/api/records` `by_tier` key: `"gold standard"` (lowercase, matches portal JS lookup).

## Portal
- CSS class: `gold` (amber #f59e0b). `.pick-card.gold`, `.tier-badge.gold`, `.tier-dot.gold`.
- `tierLabel()` and `tierCls()` both handle `"gold standard"` and legacy `"edge"` → maps to gold.
- Tier records table: 3 rows (nuke, diamond, gold standard).

## confidence_caps.py
- All `"Edge"` keys → `"Gold Standard"` in `CONFIDENCE_CAPS` dict.

## Telegram
- `TIER_HEADERS[Tier.GOLD] = "🥇 GOLD STANDARD PICK"`
- `_REVAL_TIER_HEADER["Gold Standard"]` and legacy `"Edge"` both map to "🥇 GOLD STANDARD PICK UPDATED".

## How to apply
- Never use `Tier.EDGE` or the string `"Edge"` for tier assignment anywhere.
- `Tier.GOLD` is imported from `core.decision_gatekeeper`.
- The `_tier_order` list in gatekeeper is `[Tier.NUKE, Tier.DIAMOND, Tier.GOLD]`.

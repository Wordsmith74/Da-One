"""
wnba_opp_intel.py — WNBA Opponent & Game-Environment Intelligence
=================================================================

Three multiplicative projection-adjustment layers for WNBA assists and
rebounds props.  All adjustments compound on top of the base per-minute
× projected-minutes projection in _wnba_prop_projection().

Layer 1 — Shooting Environment  (assists only)
    Assists require made baskets.  Games where both teams allow more
    scoring create a richer assist environment; stingy defences suppress it.
    Proxy: average of both teams' points-allowed vs WNBA league average.
    Multiplier range: [0.92, 1.08]

Layer 2 — Rebounding Environment  (rebounds only)
    Missed shots create rebounds.  An opponent that dominates the boards
    leaves fewer opportunities for our player.
    Proxy: opponent's average rebounds vs WNBA league average, inverted.
    Multiplier range: [0.92, 1.08]

Layer 3 — Blowout Risk  (all markets via minutes dampener)
    Large point spreads (>= 10) indicate meaningful garbage-time risk.
    Blowouts compress the playing time of starters — especially the
    favoured team's in the final quarter.  Applied conservatively (70 %
    of full dampener) to all players because we cannot always identify
    which team the player is on.
    Multiplier range: [0.92, 1.00]  — only reduces, never inflates.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger("betting_bot")

# ── WNBA league averages (2025 season estimates) ──────────────────────────────
_LG_AVG_PTS_ALLOWED: float = 82.0   # points allowed per game, league mean
_LG_AVG_REB:         float = 33.0   # total rebounds per game, league mean

# ── Blowout thresholds ────────────────────────────────────────────────────────
# Two-tier model: moderate (spread 10–17) / heavy (spread ≥ 17).
# Multipliers target projected-minutes × 0.85 (moderate) / 0.70 (heavy) but
# are applied conservatively at 70 % weight since we can't always identify
# which team the player is on.
#   moderate: 1.0 − (1.0−0.85) × 0.70 = 0.895
#   heavy:    1.0 − (1.0−0.70) × 0.70 = 0.79
_BLOWOUT_MODERATE: float = 10.0   # |spread| ≥ this → "moderate" tier
_BLOWOUT_HEAVY:    float = 17.0   # |spread| ≥ this → "heavy" tier
_BLOWOUT_MULT: dict[str, float] = {
    "moderate": 0.895,
    "heavy":    0.790,
}

# ── Process-level cache: one ESPN call per team per engine run ────────────────
_TEAM_STATS_CACHE: dict[str, list[dict]] = {}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _espn_team_stats(team_abbr: str) -> list[dict]:
    """
    Fetch and flatten ESPN team statistics for a WNBA team.
    Results are cached for the lifetime of the process.
    """
    if team_abbr in _TEAM_STATS_CACHE:
        return _TEAM_STATS_CACHE[team_abbr]

    flat: list[dict] = []
    try:
        from core.data_fetcher import fetch_espn

        result = fetch_espn(f"basketball/wnba/teams/{team_abbr}/statistics")
        if result.ok and result.data:

            def _walk(node: object) -> None:
                if isinstance(node, list):
                    for item in node:
                        _walk(item)
                elif isinstance(node, dict):
                    if "name" in node and "value" in node:
                        flat.append({"name": node["name"], "value": node["value"]})
                    for v in node.values():
                        _walk(v)

            _walk(result.data)
    except Exception as exc:
        logger.debug(f"[wnba_opp_intel] ESPN stats failed for {team_abbr}: {exc}")

    _TEAM_STATS_CACHE[team_abbr] = flat
    return flat


def _stat(flat: list[dict], *aliases: str) -> float | None:
    """Extract the first matching stat from a flat ESPN stat list."""
    by_name = {s.get("name", ""): s.get("value") for s in flat}
    for alias in aliases:
        val = by_name.get(alias)
        if val is not None:
            try:
                return float(val)
            except (TypeError, ValueError):
                continue
    return None


# ── Odds API full team name → ESPN team abbreviation ─────────────────────────
# Keyword-based so minor name variants ("LA Sparks" vs "Los Angeles Sparks") still match.
_NAME_KEYWORDS: list[tuple[str, str]] = [
    ("atlanta",      "ATL"),
    ("chicago",      "CHI"),
    ("connecticut",  "CON"),
    ("dallas",       "DAL"),
    ("golden state", "GOL"),
    ("indiana",      "IND"),
    ("las vegas",    "LV"),
    ("los angeles",  "LA"),
    ("minnesota",    "MIN"),
    ("new york",     "NY"),
    ("phoenix",      "PHX"),
    ("portland",     "POR"),
    ("san antonio",  "SA"),
    ("seattle",      "SEA"),
    ("washington",   "WAS"),
]


def _to_abbr(full_name: str) -> str | None:
    lower = full_name.lower()
    for keyword, abbr in _NAME_KEYWORDS:
        if keyword in lower:
            return abbr
    return None


# ---------------------------------------------------------------------------
# Public result type
# ---------------------------------------------------------------------------

@dataclass
class WNBAOppIntel:
    """
    Multiplicative adjustments for a single WNBA player prop projection.

    shooting_mult  — Layer 1: game shooting-environment factor (assists)
    rebound_mult   — Layer 2: opponent rebounding-environment factor (rebounds)
    blowout_mult   — Layer 3: projected-minutes dampener (0.895 moderate / 0.79 heavy)
    blowout_level  — Tier classification: "none" | "moderate" | "heavy"
    diag           — human-readable breakdown for logger.debug
    """
    shooting_mult: float = 1.0
    rebound_mult:  float = 1.0
    blowout_mult:  float = 1.0
    blowout_level: str   = "none"
    diag:          str   = ""


# ---------------------------------------------------------------------------
# Main public function
# ---------------------------------------------------------------------------

def get_wnba_opp_intel(
    home_team: str,
    away_team: str,
    market: str,
    spread: float | None = None,
) -> WNBAOppIntel:
    """
    Compute three multiplicative projection adjustments for a WNBA prop.

    Parameters
    ----------
    home_team : Full team name from the Odds API, e.g. "Los Angeles Sparks".
    away_team : Full team name from the Odds API, e.g. "Portland Fire".
    market    : "player_assists" or "player_rebounds".
    spread    : Home-team point spread (negative = home favoured).
                None disables the blowout layer.
    """
    parts: list[str] = []
    shoot_mult   = 1.0
    reb_mult     = 1.0
    blowout_mult = 1.0

    home_abbr = _to_abbr(home_team)
    away_abbr = _to_abbr(away_team)

    try:
        # ── Layer 1: Shooting Environment → assist projection ──────────────
        # ESPN exposes each team's own offensive stats, not their defensive
        # pts-allowed.  We use each team's avgPoints as the shooting-environment
        # signal: a game between two high-scoring teams creates more made baskets
        # → more assist opportunities for ball-handlers on either side.
        # Combined avg vs league baseline drives the multiplier.
        if market == "player_assists":
            avg_pts_vals: list[float] = []
            for abbr in filter(None, [home_abbr, away_abbr]):
                flat = _espn_team_stats(abbr)
                v = _stat(flat, "avgPoints", "pointsPerGame", "pts")
                if v is not None:
                    avg_pts_vals.append(v)

            if avg_pts_vals:
                combined_avg_pts = sum(avg_pts_vals) / len(avg_pts_vals)
                ratio  = combined_avg_pts / _LG_AVG_PTS_ALLOWED
                # +6 % max boost in a high-scoring game; −6 % when both teams struggle
                shoot_mult = round(1.0 + (ratio - 1.0) * 0.6, 3)
                shoot_mult = max(0.92, min(1.08, shoot_mult))
                parts.append(
                    f"combined_avg_pts={combined_avg_pts:.1f} "
                    f"(lg={_LG_AVG_PTS_ALLOWED:.0f}) shoot×{shoot_mult:.3f}"
                )
            else:
                parts.append("avg_pts=N/A shoot×1.0")

        # ── Layer 2: Rebounding Environment → rebound projection ───────────
        if market == "player_rebounds":
            reb_vals: list[float] = []
            for abbr in filter(None, [home_abbr, away_abbr]):
                flat = _espn_team_stats(abbr)
                v = _stat(flat,
                          "avgRebounds",
                          "reboundsPerGame",
                          "reb")
                if v is not None:
                    reb_vals.append(v)

            if reb_vals:
                avg_reb = sum(reb_vals) / len(reb_vals)
                ratio   = avg_reb / _LG_AVG_REB
                # High combined rebounding → every board is more contested
                # Low combined rebounding → more available boards
                reb_mult = round(1.0 + (1.0 - ratio) * 0.5, 3)
                reb_mult = max(0.92, min(1.08, reb_mult))
                parts.append(
                    f"avg_reb={avg_reb:.1f} "
                    f"(lg={_LG_AVG_REB:.0f}) reb×{reb_mult:.3f}"
                )
            else:
                parts.append("avg_reb=N/A reb×1.0")

        # ── Layer 3: Blowout Risk → tiered minutes dampener ───────────────
        blowout_level = "none"
        if spread is not None:
            abs_sp = abs(spread)
            if abs_sp >= _BLOWOUT_HEAVY:
                blowout_level = "heavy"
                blowout_mult  = _BLOWOUT_MULT["heavy"]
                parts.append(
                    f"spread={spread:+.1f} (≥{_BLOWOUT_HEAVY:.0f}) "
                    f"HEAVY blowout×{blowout_mult:.3f}"
                )
            elif abs_sp >= _BLOWOUT_MODERATE:
                blowout_level = "moderate"
                blowout_mult  = _BLOWOUT_MULT["moderate"]
                parts.append(
                    f"spread={spread:+.1f} (≥{_BLOWOUT_MODERATE:.0f}) "
                    f"MODERATE blowout×{blowout_mult:.3f}"
                )
            else:
                parts.append(f"spread={spread:+.1f} no blowout risk")
        else:
            parts.append("spread=None blowout skipped")

    except Exception as exc:
        logger.debug(f"[wnba_opp_intel] error ({home_team} vs {away_team}): {exc}")

    return WNBAOppIntel(
        shooting_mult = shoot_mult,
        rebound_mult  = reb_mult,
        blowout_mult  = blowout_mult,
        blowout_level = blowout_level,
        diag          = " | ".join(parts),
    )

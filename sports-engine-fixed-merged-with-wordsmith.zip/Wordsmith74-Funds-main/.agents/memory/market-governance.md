---
name: Market governance — publication whitelist
description: Publication whitelist, Diamond cap expansion, and Tier-1 market priority ranking implemented in core/market_governance.py
---

## Rule
Only the 8 approved (sport, market) pairs may appear in any public-facing output (Telegram, MiniApp, Discord, website). All other markets are Secondary Research — the engine evaluates them internally but never logs or broadcasts picks from them.

## Approved markets (normalized keys)
- MLB: `player_strikeouts` (priority 1), `first_5_total` (priority 2), `totals` (priority 6)
- NBA: `player_assists` (priority 3), `totals` (priority 7)
- WNBA: `player_assists` (priority 4), `player_rebounds` (priority 5), `totals` (priority 8)

## F5 market key
The API key is `totals_first_5_innings`; the internal normalized label is `first_5_total` (set in game_markets._MARKET_LABEL).

## Diamond cap
Changed from 1 → **2 per day**. `diamond_slots` counter in `_apply_global_tier_cap`; `send_daily_picks` uses `diamond_pool[:2]`.

## Priority tiebreaker
When multiple (sport, market) filter groups score equally, `publication_priority()` (lower = better) breaks the tie in `dominant_key` selection via `(*_filter_score(...), -priority)` tuple comparison.

## Publication gate placement
- `_apply_global_tier_cap`: research-market Nuke/Diamond picks demoted to Gold Standard **before** eligible/ineligible partition.
- `_mode_run` and `_mode_picks`: `pub_display` / `pub_log_dicts` filter runs **before** `log_bet_dict` and before assembling `bets_by_sport`. Research picks are never written to DB.

**Why:** Keeps DB and MiniApp clean with no schema changes needed — research picks simply never enter the logging or broadcast pipeline.

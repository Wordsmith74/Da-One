---
name: WNBA ESPN abbreviation mismatches
description: The engine and odds feed use different team abbreviations than ESPN returns; alias map fixes silent grading failures.
---

## Problem
`score_grader._event_abbrs()` returns ESPN's abbreviations. The engine stores odds-feed abbreviations. Mismatches cause silent grade failures — the team lookup returns no match, the bet stays open forever.

## Known aliases (engine → ESPN)
| Engine | ESPN | Team |
|--------|------|------|
| WAS    | WSH  | Washington Mystics |
| GOL    | GS   | Golden State Valkyries |
| LAS    | LV   | Las Vegas Aces |
| LAX    | LA   | LA Sparks |
| NYL    | NY   | New York Liberty (bidirectional) |

## Fix location
`core/score_grader.py` — `_ABBR_ALIASES` dict + `_event_abbrs()` now adds aliases to the returned set, so `target & _event_abbrs(ev)` succeeds even when abbreviations differ.

**Why:** Without this, all three WNBA game-total picks from June 2 (WAS, GOL, LAS) stayed open despite final scores being available on ESPN. Had to be manually graded by querying ESPN directly and computing outcomes.

## Manual grading fallback
When the grader silently skips a bet: query ESPN scoreboard for the date → compute home+away scores → compare to sportsbook_line from `bets.wager_details` → use `_calculate_profit_loss(outcome, odds, 100.0)` → UPDATE bets directly.

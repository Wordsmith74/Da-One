---
name: WNBA per-minute model
description: Minutes-first projection framework for WNBA player_assists and player_rebounds — key design decisions and wiring.
---

## What it does
Replaces the generic `_weighted_projection()` call for WNBA props with a per-minute × projected-minutes pipeline that accounts for role and playing-time variance.

## Architecture

**`_build_wnba_stats_cache`** — now captures `_WNBA_CACHE_COLS = {"REB", "AST", "MIN"}`. The filter that gates which stat group to enter is `set(_WNBA_BOX_COL.values())` ({"REB","AST"}), not `_WNBA_CACHE_COLS`, so we only enter the main box group.

**`_wnba_minutes_classification(min_vals)`** — returns `(projected_minutes, minutes_range, stability_label)`.
- Projected minutes: recency-weighted (0.30/0.25/0.20/0.15/0.10) over L5 non-DNP games.
- Stability thresholds: elite ≤4 min range, moderate 4–8 min, volatile >8 min.

**`_wnba_classify_role(player_name, market)`** — uses cached AST/MIN and REB/MIN rates.
- `player_assists`: AST/min ≥0.12 → ballhandler; <0.07 → off_ball; else secondary.
- `player_rebounds`: REB/min ≥0.20 → frontcourt; <0.10 → guard; else wing.

**`_wnba_prop_projection(player_name, market, matchup_context)`** — full pipeline:
1. Compute raw stat averages (season, L5, L10) — still needed by gatekeeper L5 cold-streak brake.
2. Project minutes + stability via `_wnba_minutes_classification`.
3. Per-minute rate: recency-weighted (0.40/0.25/0.20/0.10/0.05); blended 60% recent / 40% season.
4. Role multiplier: AST→{ballhandler:1.15, secondary:1.05, off_ball:0.80}; REB→{frontcourt:1.10, wing:1.00, guard:0.85}.
5. Opponent adjustment: hook wired, returns 1.0 (neutral) until team-roster data available.
6. Final: `(per_min_rate × proj_min × role_adj × opp_adj) × 0.70 + legacy × 0.30`.

## Candidate builder changes
For `sport_up == "WNBA"`, calls `_wnba_prop_projection` instead of `_espn_player_stats` + `_weighted_projection`. Sets four new fields on the candidate dict (carried into `bet.raw_result`):
- `minutes_stability` — "elite" / "moderate" / "volatile"
- `projected_minutes` — L5-weighted minutes projection
- `minutes_range` — L5 max−min range in minutes
- `role_label` — ballhandler / secondary / off_ball / frontcourt / wing / guard

## Gatekeeper Step 1b2
Inserted after Step 1b (restricted market cap) and before Step 1c (V3.0 confidence caps). Reads `bet.raw_result.get("minutes_stability")`. Applies only to `player_assists` and `player_rebounds` markets.
- "volatile": Nuke/Diamond → Gold Standard
- "moderate": Nuke → Diamond
- "elite": no cap

## Why
WNBA minutes distribution is highly variable (load management, foul trouble, blowouts). A player projected at 35 AST/min but playing only 12 minutes in a blowout causes large projection misses. Anchoring the projection on expected minutes and penalizing volatile-minutes players at the tier level reduces overconfident WNBA prop picks.

## Odds API WNBA prop coverage
As of June 2026, the Odds API's `basketball_wnba` player prop markets are sparse — POR@LAS on 2026-06-07 had no prop lines. The model activates when lines are available; no action needed.

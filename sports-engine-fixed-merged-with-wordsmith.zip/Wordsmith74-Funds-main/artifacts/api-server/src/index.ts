import app from "./app";
import { logger } from "./lib/logger";
import { startDailyScheduler, runStartupGrade } from "./routes/admin";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Arm the daily 8:30 AM ET picks + evening grade schedulers
  startDailyScheduler();

  // Grade any stale open picks immediately on startup so records stay current
  void runStartupGrade();
});

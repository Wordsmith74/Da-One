#!/bin/bash
# Production entry point — runs inside the Replit VM deployment.
# Starts the Python scheduling daemon in the background with an auto-restart
# watchdog, then runs the Node.js API server in the foreground.
set -euo pipefail

cd /home/runner/workspace

mkdir -p logs

# Watchdog: restarts the scheduler if it exits for any reason (crash, OOM, etc.)
# Each restart is logged with a timestamp so failures are traceable.
_scheduler_watchdog() {
    while true; do
        echo "[watchdog] $(date '+%Y-%m-%d %H:%M:%S ET') starting scheduler..." >> logs/scheduler.log
        python3 scripts/production_scheduler.py >> logs/scheduler.log 2>&1 || true
        EXIT_CODE=$?
        echo "[watchdog] scheduler exited (code $EXIT_CODE) — restarting in 15s..." >> logs/scheduler.log
        sleep 15
    done
}

echo "[start] Launching scheduler watchdog..."
_scheduler_watchdog &
WATCHDOG_PID=$!
echo "[start] Watchdog running (PID $WATCHDOG_PID)"

# Forward SIGTERM/SIGINT — kill the watchdog group so scheduler also stops
trap "kill $WATCHDOG_PID 2>/dev/null; exit" TERM INT

echo "[start] Starting Node.js API server..."
# CD into the artifact directory so process.cwd() matches the dev workflow CWD.
# This is required for DB_PATH resolution: path.resolve(cwd, "..", "..", "data", "results.db")
# The watchdog subshell above already forked with workspace-root CWD, so this cd only affects node.
cd /home/runner/workspace/artifacts/api-server
exec node --enable-source-maps dist/index.mjs

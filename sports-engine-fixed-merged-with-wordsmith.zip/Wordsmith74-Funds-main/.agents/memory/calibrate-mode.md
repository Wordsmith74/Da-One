---
name: Calibrate mode design
description: Two-scenario proof that playoff context flips tiers; data constraints for valid calibration scenarios
---

## Rule
`python3 main.py --mode calibrate` runs `_mode_calibrate()` — no DB writes, no Telegram. Validates that regular vs playoff contexts produce **different** tier outcomes for two designed scenarios. Raises `RuntimeError` (and exits 1) if any scenario shows the same tier in both contexts.

**Why:** Proves the playoff prior-tightening and recent-N slicing in `SimulationEngine.analyze()` actually change decisions, not just intermediate numbers.

**How to apply:** Run after any change to the simulation engine or tier thresholds to confirm context-awareness is preserved.

## Scenario design constraints

**Critical insight:** When you reverse game order (hot-first vs cold-first), the full-10-game *mean* is identical → Regular context DISCARDs in both cases. You must choose histories where the *all-10 mean* is clearly above the line in one scenario and clearly below in the other.

### Scenario A — Hot Finish (Regular=DISCARD, Playoff=S+)
- hist=[8,9,8,7,9, **17,18,19,17,18**], line=14.5, league_mean=13.5, std=5.0
- All-10 mean≈13.0 (near/below line) → Regular posterior pulled to ~13 → negative edge → DISCARD
- Last-5 mean≈17.6 (well above line) with tight playoff prior → posterior ~17.6 → S+

### Scenario B — Cold Finish (Regular=S+, Playoff=DISCARD)
- hist=[**17,16,17,16,17**, 14,15,14,15,14], line=14.5, league_mean=13.5, std=5.0
- All-10 mean≈15.5 (above line, low variance) → Regular posterior ~15.5, conf≥95% → S+
- Last-5 mean≈14.4 (just below line) with tight playoff prior → posterior ~14.4 → negative edge → DISCARD

## Verified outputs (NBA, volatility_index=1.8)
| Scenario | ctx | N | mean | std | model% | edge% | conf | Tier |
|---|---|---|---|---|---|---|---|---|
| A Hot Finish | regular | 10 | 13.04 | 1.59 | 17.5 | -34.9 | 73.0 | DISCARD |
| A Hot Finish | playoff | 5 | 17.58 | 0.63 | 100.0 | 47.6 | 99.0 | S+ (NUKE) |
| B Cold Finish | regular | 10 | 15.49 | 0.48 | 97.9 | 45.5 | 99.0 | S+ (NUKE) |
| B Cold Finish | playoff | 5 | 14.39 | 0.40 | 30.6 | -21.8 | 56.8 | DISCARD |

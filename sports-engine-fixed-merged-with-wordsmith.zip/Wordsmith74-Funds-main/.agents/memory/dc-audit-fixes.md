---
name: Double-counting audit & fixes
description: Six confirmed double-counting issues in the confidence/edge pipeline; five fixes implemented June 2026.
---

# Double-Counting / Redundant Penalties — Audit & Fixes

**Why:** Systematic audit revealed six sites where the same raw signal penalized confidence/edge through two independent code paths simultaneously, suppressing picks that should have cleared tier thresholds.

## Confirmed Issues (ID → severity → status)

| ID | Signal | Double path | Fix applied |
|----|--------|-------------|-------------|
| DC-1 | L5 average | NUTS posterior already shapes confidence from L5 data; gatekeeper Step 6 also subtracted up to 25 conf pts from same L5 vs line gap | ✅ Fixed |
| DC-2 | sharp_contrary | Step 1d (conf/edge/tier penalty) fired before Step 1.6 hard-block; deductions wasted on already-dead picks | ✅ Fixed |
| DC-3 | Low MAS | Step 1d applied BOTH tier downgrade AND conf/edge penalties unconditionally from one MAS reading | ✅ Fixed |
| DC-4 | MIS score | compute_effective_edge() adj (±0.5/−1.0%) AND MAS→conf penalty path both sourced from MIS | ✅ Fixed |
| DC-5 | stability_score | CCS Factor 1 (30% weight) AND Factor 4 (45% weight) both used stability_score → ~29% CCS from one metric | ✅ Fixed |
| DC-6 | RLM/steam | Positive: three rewards (eff_edge, MAS, CCS sharp_score) from same detection event | Not fixed (benign) |

## Fixes Applied

**Fix 1 (DC-1): decision_gatekeeper.py Step 6 — reduced L5 brake**
- When `raw_result.get("l5_in_simulation", True)` (default True = L5 was in NUTS): max penalty = 10 pts, coefficient ×20
- When `l5_in_simulation=False` (season-avg-only posterior): full brake, max 25 pts, ×40
- Default True means existing picks never get the old 25-pt double-penalty; False can be set by prop pipeline in future

**Fix 2 (DC-2): decision_gatekeeper.py — Step 1.6 moved BEFORE Step 1d**
- Hard-block checks (eff_edge<0, sharp_contrary, edge_decay>3) now fire before MAS agreement penalties
- sharp_contrary picks are discarded cleanly with one log reason instead of getting deducted then discarded

**Fix 3 (DC-3): decision_gatekeeper.py Step 1d — mutually exclusive mechanisms**
- `_was_downgraded = not _tier_passes_agreement(...)`: if True → tier drops, NO conf/edge penalty
- if False → tier passed but soft penalty applies (agreement weak but not floor-failing)
- Same MAS reading now drives exactly one outcome, never both

**Fix 4 (DC-4): market_intelligence.py compute_effective_edge()**
- Removed MIS adjustment block (`if mis_score >= 80: adj += 0.5 / elif mis_score < 40: adj -= 1.0`)
- MIS fully represented through compute_market_agreement() → MAS → gatekeeper penalty path

**Fix 5 (DC-5): composite_confidence_score.py _f4_volatility()**
- Replaced `stab = stability_score × 10` with `mis = float(bd.bet.mis_score or 0)` (0–100)
- Factor 4 now measures market depth/consensus quality, independent from velocity-based Factor 1
- stability_score remains in Factor 1 only; total CCS weight from that metric drops from ~29% → ~9%

## How to Apply l5_in_simulation Flag (Future Enhancement)
In player_props.py, when building the candidate dict, add:
```python
c["l5_in_simulation"] = (l5_avg is not None)
```
This allows game-market candidates (which never have l5_avg) to use full brake if their NUTS used season-only data.

## Impact Observed on First Post-Fix Run (2026-06-10)
- WNBA: 1 approved (up from 0 without fixes on same slate)
- MLB: 3 approved, 2 broadcast + 1 held (pending signal confirmation cy=2)
- 2 picks broadcast: Kelsey Plum assists OVER (WNBA, Gold Standard, edge=9.06%, conf=84.0) + OAK total UNDER (MLB, Gold Standard, edge=5.33%, conf=72.8)
